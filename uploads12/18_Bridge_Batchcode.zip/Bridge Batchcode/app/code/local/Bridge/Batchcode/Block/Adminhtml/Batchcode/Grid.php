<?php

/**
 * Bridge Batchcode
 *
 * @category      Bridge
 * @package       Bridge_Batchcode
 * @copyright     Copyright (c) 2013 Bridge India. (http://bridge-india.in)
 * @license       http://bridge-india.in/disclaimer/magento
 */
class Bridge_Batchcode_Block_Adminhtml_Batchcode_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct($arguments=array())
    {
        parent::__construct($arguments);
        $this->setId('batchcodeGrid');
        $this->setUseAjax(true);
        $this->setDefaultSort('entity_id');
        $this->setSaveParametersInSession(true);
           }

    /**
     * Prepare grid collection object
     *
     * @return this
     */
    protected function _prepareCollection()
    {
        $collection = Mage::getModel('batchcode/batchcode')
                        ->getCollection()
                        ->getAllBatchDetails()

        ;
        $this->setCollection($collection);

        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn('entity_id', array(
            'header' => Mage::helper('batchcode')->__('ID'),
            'align' => 'right',
            'width' => '10px',
            'index' => 'entity_id',
        ));

        $this->addColumn('product_id', array(
            'header' => Mage::helper('batchcode')->__('Product ID'),
            'align' => 'right',
            'width' => '10px',
            'index' => 'product_id',
        ));

        $this->addColumn('name', array(
            'header' => Mage::helper('batchcode')->__('Batch Number'),
            'align' => 'left',
            'index' => 'batch_number',
            'width' => '50px',
        ));

        $this->addColumn('qty', array(
            'header' => Mage::helper('batchcode')->__('Qty'),
            'width' => '150px',
            'index' => 'qty',
        ));

 $this->addColumn('onsales', array(
            'header' => Mage::helper('batchcode')->__('Onsale'),
            'width' => '150px',
          'type'     => 'options',
          'options'  => array(
                Mage::helper('batchcode')->__('NO'),
                Mage::helper('batchcode')->__('YES')
            ),
           'renderer' => new Bridge_Batchcode_Block_Adminhtml_Renderer_Status(),
           'index' => 'onsales'
        ));

        $this->addColumn('priority', array(
            'header' => Mage::helper('batchcode')->__('Priority'),
            'width' => '150px',
            'index' => 'sales_priority',
        ));

        $this->addColumn('action',
                array(
                    'header' => Mage::helper('batchcode')->__('Action'),
                    'width' => '100',
                    'type' => 'action',
                    'getter' => 'getId',
                    'actions' => array(
                        array(
                            'caption' => Mage::helper('batchcode')->__('Edit'),
                            'url' => array('base' => '*/*/edit'),
                            'field' => 'id'
                        )
                    ),
                    'filter' => false,
                    'sortable' => false,
                    'index' => 'stores',
                    'is_system' => true,
                )
        );

        $this->addColumn('Customers',
                array(
                    'header' => Mage::helper('batchcode')->__('Customers'),
                    'width' => '100',
                    'type' => 'action',
                    'getter' => 'getId',
                    'actions' => array(
                        array(
                            'caption' => Mage::helper('batchcode')->__('Customers'),
                            'url' => array('base' => '*/adminhtml_customer/index'),
                            'field' => 'id'
                        )
                    ),
                    'filter' => false,
                    'sortable' => false,
                    'index' => 'stores',
                    'is_system' => true,
                )
        );

        $this->addColumn('Guests',
                array(
                    'header' => Mage::helper('batchcode')->__('Guests'),
                    'width' => '100',
                    'type' => 'action',
                    'getter' => 'getId',
                    'actions' => array(
                        array(
                            'caption' => Mage::helper('batchcode')->__('Guests'),
                            'url' => array('base' => '*/adminhtml_guest/index'),
                            'field' => 'id'
                        )
                    ),
                    'filter' => false,
                    'sortable' => false,
                    'index' => 'stores',
                    'is_system' => true,
                )
        );

        $this->addColumn('Orders',
                array(
                    'header' => Mage::helper('batchcode')->__('Orders'),
                    'width' => '100',
                    'type' => 'action',
                    'getter' => 'getId',
                    'actions' => array(
                        array(
                            'caption' => Mage::helper('batchcode')->__('Orders'),
                            'url' => array('base' => '*/adminhtml_order/index'),
                            'field' => 'id'
                        )
                    ),
                    'filter' => false,
                    'sortable' => false,
                    'index' => 'stores',
                    'is_system' => true,
                )
        );

        return parent::_prepareColumns();
    }

    /**
     * Prepare grid massaction actions
     */
    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('entity_id');
        $this->getMassactionBlock()->setFormFieldName('batchcode');

        $this->getMassactionBlock()->addItem('delete', array(
            'label' => Mage::helper('batchcode')->__('Delete'),
            'url' => $this->getUrl('*/*/massDelete'),
            'confirm' => Mage::helper('batchcode')->__('Are you sure?')
        ));

        return $this;
    }

    /**
     * Grid url getter
     *
     *
     * @return string current grid url
     */
    public function getGridUrl()
    {
        return $this->getUrl('*/*/*/grid', array('_current' => true));
    }

    /**
     * Grid row getter

     */
    public function getRowUrl($row)
    {
        return $this->getUrl('*/*/*/edit', array('id' => $row->getId()));
    }

}
