<?php

use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableInterface;

class Appointment extends Eloquent
{
	protected $fillable = array( 'to_user', 'by_user', 'status' );

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'appointments';

	public function toUser()
	{
		return $this->hasOne('User', 'id', 'to_user');
	}

	public function byUser()
	{
		return $this->hasOne('User', 'id', 'by_user');
	}

	public function schedule()
	{
		return $this->hasOne('AppointmentSchedule', 'appointment_id', 'id');
	}

	function toArray()
	{
		$data = parent::toArray();
		$data['to_user'] = $this->toUser->toArray();
		$data['by_user'] = $this->byUser->toArray();
		$data['schedule'] = AppointmentSchedule::where('appointment_id','=', $this->id )
			->orderBy('id', 'desc')->first()->toArray();
		return $data;
	}

}