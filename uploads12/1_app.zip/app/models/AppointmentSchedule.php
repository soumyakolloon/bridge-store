<?php


use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableInterface;

class AppointmentSchedule  extends Eloquent
{

	protected $fillable = array( 'comment', 'appointment_id', 'date' );

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'appointment_schedules';
}