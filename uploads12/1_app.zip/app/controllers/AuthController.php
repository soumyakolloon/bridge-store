<?php

/**
 * SYL - Authentication API class
 */
class AuthController extends BaseController {

    protected $rules = array(
        'username' => 'required|min:4|unique:users',
        'email' => 'required|email|unique:users',
        'password' => 'required|between:3,15|confirmed',
        'password_confirmation' => 'required|between:3,15',
        //'photo' => 'mimes:jpeg,bmp,png',
        'mobile' => 'required',
        'country_code' => 'required',
        //'facetime_id'=>'unique:users',
        //'skype_id'=>'unique:users',
    );

    /**
     * Signin API method
     * @return array
     */
    function signin() {
        $authData = array(
            'username' => Input::get('username'),
            'password' => Input::get('password')
        );

        if (Auth::attempt($authData)) {
            $user = User::find(Auth::user()->id);
            $user->api_token = Hash::make(str_random());

            $device_token = Input::get('device_token');

            DB::table('devices')->where(array('id', Auth::user()->id, 'device_token' => $device_token))->update(array('api_token' => $user->api_token));

            return Response::json(array(
                        'token' => $user->api_token,
                        'user' => $user->toArray()
            ));
        } else {
            return Response::json(array("code" => 401, "message" => array("error" => "The username or password that you entered is incorrect")), 402);
        }
        return $this->errorNotExists();
    }

    /**
     * User signup
     * @return array json response
     */
    function signup() {  
                
        $validator = Validator::make(Input::all(), $this->rules);
        if (!$validator->passes()) {
            //return $this->errorFailed($validator->errors()->toArray()); 
            $validaton_results = array();
            foreach($validator->errors()->toArray() as $key => $val) {
                $validaton_results[$key] = json_encode($val[0]);                
            }
            
            $api_response['message'] = $validaton_results;
            $api_response['status'] = "failure";
            return Response::json($api_response);
        }
        
        $data = Input::get();        
        if (Input::hasFile('profile_image')) {
            $allowed = array('image/png', 'image/jpeg', 'image/jpg', 'image/gif');
            $mime = strtolower(Input::file('profile_image')->getMimeType());

            if (in_array($mime, $allowed)) {
                $extension = Input::file('profile_image')->getClientOriginalExtension();
                $originalname = Input::file('profile_image')->getClientOriginalName();
                $rawname = substr($originalname, 0, -(strlen($extension) + 1));
                $glob = glob(public_path() . "/uploads/images/$rawname*" . $extension);
                $count = count($glob);
                $count++;
                $imagepath = public_path() . "/uploads/images/";
                $imagepath_88X88 = public_path() . "/uploads/images/images_88X88/";
                $imagename = $rawname . "_" . $count . "." . $extension;

                Input::file('profile_image')->move($imagepath, $imagename);
                Image::make($imagepath . $imagename)->resize(88, 88)->save($imagepath_88X88 . $imagename);
                $data['profile_image'] = $imagename;
            } else {
                //return Response::json(array("code" => 401, "message" => array("profile_image" => "Invalid Image format")), 402);
                return Response::json(array("status" => "failure", "message" => "Invalid Image format"));
            }
        }


        unset($data['password_confirmation']);
        $data['password'] = Hash::make($data['password']);
        $newuser = User::create($data);
        
        Auth::loginUsingId($newuser->id);
        
        // Map the user id to devices and generate api_token
        $access_token = Hash::make( str_random());
        if($data['device_token'] != 0) {
            $device = Device::where('device_token', '=', $data['device_token'])->first();
            $device->user_id = $newuser->id;
            $device->api_token = $access_token;
            $device->save();        
        } else {
            $device = new Device;
            $device->user_id = $newuser->id;
            $device->device_name = 'web';
            $device->device_token = '0';
            $device->api_token = $access_token;
            $device->save();
        }
        $user = User::find(Auth::user()->id);        
        // update verificaion code
        $verify_code = str_random(3) . mt_rand(1000,9999);
        $user->verify_code = $verify_code;
        $user->save();
        
        $response_array = $user->toArray();
        $response_array['token'] = $device->api_token;
        $response_array['status'] = 'success';
        
        return Response::json(array(
                    //'token' => $device->api_token,
                    'status' => 'success',
                    'user'   => $user->toArray(),                    
                    'verify_code' => $verify_code,
                    'access_token' => $access_token
        ));
    }
    
    /**
     * Confirm wthether the user inputted code is correct
     * @return json
     */
    public function verify_code()
    {
        $data = Input::get();
        if(isset($data['user_id']) && (isset($data['code']))) {
            //$verify_code = str_random(3) . mt_rand(1000,9999);
            $user = User::find($data['user_id']);
            $code = $user->verify_code;
            if($code == $data['code']) {
                // update the verified status
                if(isset($data['method'])) {
                    if($data['method'] == 'email') {
                        $user->email_verified = 1;                        
                    } else if($data['method'] == 'mobile'){
                        $user->mobile_verified = 1;
                    }
                    $user->activated = $user->email_verified & $user->mobile_verified;
                    $user->save();                                        
                }               
                
                return Response::json(array('status' => 'success'));
            } else {
                return Response::json(array('status' => 'failure', 'message' => 'code mismatch!'));
            }
            
        } else {
            return Response::json(array('status' => 'failure', 'message' => 'email and verify_code parameters required'));
        }
    }
    
    public function test() {
        echo "hello";
        $data = array('content' => 'Email content');
        Mail::send('emails.welcome', $data, function($message)
        {
            $message->to('sobin87@gmail.com', 'Sobin Yohannan')->subject('Welcome!');
        });
        
        echo 'After email sent...';die();
    }

}
