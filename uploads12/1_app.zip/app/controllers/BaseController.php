<?php

class BaseController extends Controller {

	/**
	 * Setup the layout used by the controller.
	 *
	 * @return void
	 */
	protected function setupLayout()
	{
		if ( ! is_null($this->layout))
		{
			$this->layout = View::make($this->layout);
		}
	}

	protected function errorFailed( $message = 'Failed request' )
	{
		return Response::json( array(
			'code' => 401,
			'message' => $message 
		), '402' );
	}

	protected function errorNotAccess()
	{
		return Response::json( array(
			'code' => 401,
			'message' => 'Unauthorized request'
		), '401' );
	}


	protected function errorNotExists()
	{
		return Response::json( array(
			'code' => 404,
			'message' => 'Resource was not found'
		), '404' );
	}
}
