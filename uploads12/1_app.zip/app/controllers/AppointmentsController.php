<?php

class AppointmentsController extends BaseController 
{

	public function listAll( $user_id = 0 )
	{
		$user_id = (int) $user_id ;
		if ( !( $user = User::find( $user_id ) ) ){
			$this->errorNotExists();
		}
		$keyMap = array(
			'2' => 'by_user',
			'1' => 'to_user',
		);

		$all = Appointment::where( $keyMap[$user->group_id ], '=', $user->id )->get();
		return Response::json($all);
	}

	public function index()
	{
		 $status = Input::get('status');
		
			switch ($status) {
				case 'requested':
					if(Auth::user()->group_id==1)
					$appoitments = Appointment::where('to_user', '=', Auth::user()->id)
												->where('status','=','1')
												->paginate(15);
					else
					$appoitments = Appointment::where('by_user', '=', Auth::user()->id)
												->where('status','=','1')
												->paginate(15);	
					return Response::json( $appoitments);
					
				break;
				case 'confirmed':
					if(Auth::user()->group_id==1)
					$appoitments = Appointment::where('to_user', '=', Auth::user()->id)
												->where('status','=','2')
												->paginate(15);
					else
					$appoitments = Appointment::where('by_user', '=', Auth::user()->id)
												->where('status','=','2')
												->paginate(15);	
					return Response::json( $appoitments);
					
				break;
				case 'cancelled':
					if(Auth::user()->group_id==1)
					$appoitments = Appointment::where('to_user', '=', Auth::user()->id)
												->where('status','=','2')
												->paginate(15);
					else
					$appoitments = Appointment::where('by_user', '=', Auth::user()->id)
												->where('status','=','2')
												->paginate(15);	
					return Response::json( $appoitments);
				break;
				case 'rescheduled':
					if(Auth::user()->group_id==1)
					$appoitments = Appointment::where('to_user', '=', Auth::user()->id)
												->where('status','=','2')
												->paginate(15);
					else
					$appoitments = Appointment::where('by_user', '=', Auth::user()->id)
												->where('status','=','2')
												->paginate(15);	
					return Response::json( $appoitments);
				break;
				default:
					if(Auth::user()->group_id==1)
					$appoitments = Appointment::where('to_user', '=', Auth::user()->id)->paginate(15);
					else
					$appoitments = Appointment::where('by_user', '=', Auth::user()->id)->paginate(15);	
					return Response::json( $appoitments);
				break;
			

		}

		
	}


	public function show( $id = 0 )
	{
		$id = (int) $id;
		$app  = Appointment::find( $id );
		if ( !$app ) {
			return $this->errorNotExists();
		}
		return Response::json( $app );
	}


	public function reschedule( $id = 0 )
	{

		$app  = Appointment::find( $id );
		if ( !$app ) {
			return $this->errorNotAccess();
		}

		$app->status = 4;
		$app->save();

		$all = Input::all();
		$shedule = AppointmentSchedule::create( array(
			'appointment_id' => $app->id ,
			'comment'	=> $all['comment'],
			'date'		=> $all['date'],
		));

		return Response::json( Appointment::find( $id ) );
	}

	/**
	 * Confirm appointment by Doctor
	 * 
	 * @param int $id
	 * @return string
	 */
	public function confirm( $id = 0 )
	{
		// check logged in user is owner of this appointment
		$id = (int) $id ;
		$app  = Appointment::find( $id );
		if ( !$app ) {
			return $this->errorNotExists();
		}

		//$userId = $this->getLoggedUser();
		
		if ( $app->to_user != Auth::user()->id ) {
			return $this->errorNotAccess();
		}

		$app->status = 3;
		$app->save();
		return Response::json( $app );
	}

	public function cancel( $id = 0 )
	{
		return $this->update( $id , array(
			'status' => 2
		));
	}

	public function update( $id = 0, $data = array() )
	{
		$id = (int) $id ;
		$app  = Appointment::find( $id );
		if ( !$app ) {
			return $this->errorNotExists();
		}

		$app->update( $data );
		$app->save();
		return Response::json( $app );
	}


	public function store()
	{
		$all = Input::all();
		
		if ( !User::find(Input::get('to_user')) || !User::find(Input::get('by_user'))  ) {
			return $this->errorNotAccess();
		}

		$app = Appointment::create( array_merge( $all, array(
			'status' => 1
		)));

		$shedule = AppointmentSchedule::create( array(
			'appointment_id' => $app->id ,
			'comment'	=> $all['comment'],
			'date'		=> $all['date'],
		));

		return Response::json( $app );
	}


	public function destroy( $id )
	{
		if ( !($app = Appointment::find( $id )) ) {
			return $this->errorNotExists();
		}

		$app->delete();
		return Response::json();
	}

}
