<?php

class PushController extends BaseController 
{

public function ios()
	{

		$message  = Input::get('message');
		$devicetoken = Input::get('devicetoken');	

			$level = 1;
		    $sandbox               =  1;
		            // Put your private key's passphrase here:
	        $passphrase = 'safil123';//'pushchat';

				$ctx = stream_context_create();
			    stream_context_set_option($ctx, 'ssl', 'local_cert','/var/www/apns-dev.pem');
			    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

			// Open a connection to the APNS server
			$fp = stream_socket_client(
				'ssl://gateway.sandbox.push.apple.com:2195', $err,
				$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

			if (!$fp)
			{
				echo "failed";
			}else{
				echo "\n connected \n";
			}
			
			// Create the payload body
			$body['aps'] = array(
				'alert' => $message,
				'sound' => 'default.aiff',
				'badge' => $level
				);
			
			// Encode the payload as JSON
			$payload = json_encode($body);
			
			// Build the binary notification
			$msg = chr(0) . pack('n', 32) . pack('H*', $devicetoken) . pack('n', strlen($payload)) . $payload;

		// Send it to the server
		$result = fwrite($fp, $msg, strlen($msg));
		
		$messageArray    = array();
			if (!$result)
			{
				$messageStatus =  array('response'=>'Error in processing');
			}
			else
			{
				$messageStatus = array('response'=>'Successfully processed');
		
			}
	// Close the connection to the server
		fclose($fp);
		//echo json_encode($messageStatus);
		$message = array();
	}


}

?>