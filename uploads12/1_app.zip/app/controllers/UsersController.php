<?php

class UsersController extends BaseController {

    public function listAll() {
        $users = User::all();
        return Response::json($users);
    }

    public function listByGroupId($id) {

        if (!isset($id)) {
            return Response::json(array('null', 402));
        } else {
            $users = User::where('group_id', '=', $id)->paginate(2);
            ;
            return Response::json($users);
        }
    }

    public function show($id = null) {
        $id = ($id) ? $id : Auth::user()->id;
        return Response::json(User::find($id));
    }

    public function update() {
        $id = Auth::user()->id;
        $rules = array(
            //'username' => 'min:4|unique:users',
            //'email' => 'email|unique:users',
            'photo' => 'mimes:jpeg,bmp,png,jpg',
            'password' => 'between:3,12',
                //	'password_confirmation' => 'required|alpha_num|between:6,12',
                //	'facetime_id'=>'unique:users',
                //	'skype_id'=>'unique:users',
                //	'phone'=>'unique:users',
        );
        /* $validator = Validator::make(Input::all(),$rules);
          if ( ! $validator->passes()) {
          return $this->errorFailed( $validator->errors()->toArray() );
          } */

        $data = Input::all();

        unset($data['password_confirmation']);
        if (isset($data['password'])) {
            $data['password'] = Hash::make($data['password']);
        }

        if (Input::hasFile('photo')) {
            $allowed = array('image/png', 'image/jpeg', 'image/jpg', 'image/gif');
            $mime = strtolower(Input::file('photo')->getMimeType());

            if (in_array($mime, $allowed)) {
                $extension = Input::file('photo')->getClientOriginalExtension();
                $originalname = Input::file('photo')->getClientOriginalName();
                $rawname = substr($originalname, 0, -(strlen($extension) + 1));
                $glob = glob(public_path() . "/uploads/images/$rawname*" . $extension);
                $count = count($glob);
                $count++;
                $imagepath = public_path() . "/uploads/images/";
                $imagepath_88X88 = public_path() . "/uploads/images/images_88X88/";
                $imagename = $rawname . "_" . $count . "." . $extension;


                Input::file('photo')->move($imagepath, $imagename);
                //Image::save($imagepath . $imagename);
                Image::make($imagepath.$imagename)->resize(88,88)->save($imagepath_88X88.$imagename);
                $data['photo'] = $imagename;
            } else {
                return Response::json(array("code" => 401, "message" => array("photo" => "Invalid Image format")), 402);
            }
        }

        $result = User::where('id', '=', $id)->update($data);
        if ($result) {
            return Response::json(array('message' => 'Updated successfully'));
        }
    }

    public function store() {
        return Response::json(Input::get());
    }

    public function destroy() {
        return Response::json(array(
                    'id' => 10
        ));
    }

}
