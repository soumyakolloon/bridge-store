<?php

/**
 * Device related functionalities
 * @author Sobin
 */

class DeviceController extends BaseController {

    /**
     * Register the device on app install
     * @return none
     */
    public function register() {
        $device = Input::get();
        $count = Device::where('token', '=', $device['token'])->count();
        if ($count == 0) {
            DB::table('devices')->insert($device);
        }
    }
    
    /**
     * Login the device for Push notifications
     * @return none
     */
    public function device_login() {
        $device = Input::get();        
        DB::table('devices')->where('device_id', $device['device_id'])->update('is_logged_in',1);        
    }
    
    /**
     * Logot the device
     * @return none
     */
    public function device_logout() {
        $device = Input::get();        
        DB::table('devices')->where('device_id', $device['device_id'])->update('is_logged_in',0);
    }

}
