<?php

/*
  |--------------------------------------------------------------------------
  | Application Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register all of the routes for an application.
  | It's a breeze. Simply tell Laravel the URIs it should respond to
  | and give it the Closure to execute when that URI is requested.
  |
 */

Route::group(array('prefix' => 'api', 'before' => 'auth'), function() {
    Route::get('u/list', 'UsersController@listAll');
    Route::get('u/list/{type}', 'UsersController@listAll');
    Route::get('u/{user_id?}', 'UsersController@show');
    Route::post('u/edit/me', 'UsersController@update');
    Route::delete('u/{user_id}', 'UsersController@destroy');
    Route::post('u/{user_id}', 'UsersController@update');

    Route::get('list/doctors', function() {
        return (new UsersController)->listByGroupId(1);
    });
    Route::get('list/patients', function() {
        return (new UsersController)->listByGroupId(2);
    });


    Route::get('a/all', 'AppointmentsController@index');
    Route::get('a/list/{user_id}', 'AppointmentsController@listAll');
    Route::get('a/{id}', 'AppointmentsController@show');
    Route::post('a', 'AppointmentsController@store');

    Route::post('a/{id}/reschedule', 'AppointmentsController@reschedule');



    Route::get('a/{id}/confirm', 'AppointmentsController@confirm');
    Route::get('a/{id}/cancel', 'AppointmentsController@cancel');
    Route::get('a/{id}/delete', 'AppointmentsController@destroy');
});



Route::group(array('prefix' => 'api'), function() {    
    //Route::post('auth/registerdevice','DeviceController@register');
    //Route::post('auth/device_login','DeviceController@device_login');
    Route::get('auth/get', 'AuthController@test');
    Route::post('auth/signup', 'AuthController@signup');
    Route::post('auth/signin', 'AuthController@signin');
    Route::post('auth/verify_code', 'AuthController@verify_code');
});
