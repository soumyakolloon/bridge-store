<?php



return array(

    'appNameIOS'     => array(
        'environment' =>'development',
        'certificate' =>'/var/www/book-a-doctor/app/keys/ck.pem',
        'passPhrase'  =>'webcam',
        'service'     =>'apns'
    ),
    'appNameAndroid' => array(
        'environment' =>'production',
        'apiKey'      =>'yourAPIKey',
        'service'     =>'gcm'
    )

);