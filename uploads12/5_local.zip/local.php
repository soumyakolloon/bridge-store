http://www.hostgator.com/linux-system-administrator
http://www.hostgator.com/linux-system-administrator
http://www.hostgator.com/linux-system-administrator
<?php
/**
 * Local Configuration Override
 *
 * This configuration override file is for overriding environment-specific and
 * security-sensitive configuration information. Copy this file without the
 * .dist extension at the end and populate values as needed.
 *
 * @NOTE: This file is ignored from Git by default with the .gitignore included
 * in ZendSkeletonApplication. This is a good practice, as it prevents sensitive
 * credentials from accidentally being comitted into version control.
 */

if ( $_SERVER['APPLICATION_ENV'] != 'development') {
        return array();
}

//*/ local
return array(
    'data_api_host' => $_SERVER['HTTP_HOST'] == 'mopinion.loc' ? 'efm.mopinion.nl:8888' : $_SERVER['HTTP_HOST'].':8888',
    'translator' => array(
        'locale'    => 'en_US',
        'cache'     =>  array(
            'adapter' => 'filesystem'
        )
    ),
    'db' => array(
            'driver'         => 'Pdo',
            'pdodriver'      => 'mysql',            
            'driver_options' => array(
                PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\'',
                'buffer_results' => true
            ),
            'username'       => 'root',
            'password'       => '',
            'host'           => 'localhost',
            'dbname'         => 'mopinion_db',
    ),
);
//*/
